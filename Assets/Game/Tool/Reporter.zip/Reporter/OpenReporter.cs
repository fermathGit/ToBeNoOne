﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenReporter : MonoBehaviour {
    public static OpenReporter Create(GameObject Parent)
    {
        GameObject go = LoadPrefab.InstantiateDump(LoadPath.REPORTER, Parent);
        OpenReporter gameResult = go.AddComponent<OpenReporter>();
        return gameResult;
    }
   
}
